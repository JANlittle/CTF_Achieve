#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = 'seclab'
__copyright__ = 'Copyright © 2019/08/20, seclab'

import hashlib, random, signal

def truncated_hash(message, k):
    return hashlib.sha512(message).digest()[-k:]

def floyd(code, k=3):
    m0 = None
    m1 = None
    turtle = truncated_hash(code, k)
    hare   = truncated_hash(turtle, k)

    while turtle != hare:
        turtle = truncated_hash(turtle, k)
        hare   = truncated_hash(truncated_hash(hare, k), k)
    
    turtle = code
    pre_period_length = 0
    while turtle != hare:
        m0     = turtle
        turtle = truncated_hash(turtle, k)
        hare   = truncated_hash(hare, k)
        pre_period_length += 1

    if pre_period_length is 0:
        print(code, "Failed to find a collision: code was in a cycle!")
        return floyd(get_random_code())

    period_length = 1
    hare = truncated_hash(turtle, k)
    while turtle != hare:
        m1  =   hare
        hare = truncated_hash(hare, k)
        period_length += 1
    return (m0, m1, truncated_hash(m0, k), k)

def get_random_code(length=3):
    char_set = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    pw = ""
    for i in range(length):
        next_index = random.randrange(len(char_set))
        pw = pw + char_set[next_index]
    return pw

def welcom():
    signal.alarm(5)
    print(
r'''
 _____ _                 _     ____                _    
|  ___| | ___  _   _  __| |   / ___|_ __ __ _  ___| | __
| |_  | |/ _ \| | | |/ _` |  | |   | '__/ _` |/ __| |/ /
|  _| | | (_) | |_| | (_| |  | |___| | | (_| | (__|   < 
|_|   |_|\___/ \__, |\__,_|   \____|_|  \__,_|\___|_|\_\
               |___/                                                    
''')

def main():
    welcom()
    flag = open('./flag', 'r').read()

    code = get_random_code()
    m0, m1, code, k = floyd(code)

    print("Your m0 is:{:s}".format(m0.encode("hex")))
    m1 = raw_input("Please input m1:").rstrip("\n")

    try:
        m1 = m1.decode("hex")
        if (m0 != m1) and (truncated_hash(m0, k) == truncated_hash(m1, k)):
            print(flag)
            exit(1)
    except Exception as e:
        pass

    print("Fail, bye!")
    exit(1)

if __name__ == "__main__":
    main()




